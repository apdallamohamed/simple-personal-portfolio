import React from 'react'
import './Footar.css';
function Footar() {
  return (
    <div>
      <div>
        <footer>
          <div className="name2">
          <h1>All Right reserved by apdalla</h1>
          </div>
        
        </footer>
      </div>
    </div>
  )
}

export default Footar
